class User1 {

  final String? uid;
  User1({this.uid });

}